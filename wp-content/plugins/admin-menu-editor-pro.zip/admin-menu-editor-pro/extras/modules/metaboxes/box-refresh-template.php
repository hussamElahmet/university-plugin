<p>
	Refreshing available meta boxes...
	<span class="spinner is-active" style="float: none; vertical-align: bottom;"></span>

	<br>
	<progress id="ame-mb-refresh-progress" max="10" value="0.2" style="width: 150px;"></progress>
</p>

<p>
	This may take a few minutes. You'll be redirected to the settings screen when it's done.
	If the refresh takes too long or doesn't work, please go to the screen that contains
	the meta boxes that you want to hide, then go back to this page.
</p>