var $ = jQuery;
$(document).ready(function(){


	 $('#universities').DataTable({
	 	responsive:true
	 });

});


