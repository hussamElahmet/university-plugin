var $ = jQuery;
$(document).ready(function(){


	 $('#contact').DataTable({
	 	responsive:true
	 });

});


